package ru.misha.assistant

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

class ListenService : Service() {
    private lateinit var prefs: Prefs
    private lateinit var speaker: Speaker
    private lateinit var overlay: Overlay
    private var model: Model? = null
    private var flag: AtomicBoolean? = null
    private var worker: Thread? = null
    private val history = ArrayList<Pair<String, String>>()

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { Thread { refresh() }.start() }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        speaker = Speaker(this)
        overlay = Overlay(this)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("misha", "Миша", NotificationManager.IMPORTANCE_LOW))
        try {
            val n = notif("Запускаюсь…")
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) {
            Log.e("Misha", "foreground", e); stopSelf(); return
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rx, f)
        Thread { if (ensureModel()) refresh() }.start()
    }

    override fun onDestroy() {
        try {
            flag?.set(false)
            unregisterReceiver(rx)
            speaker.stop(); speaker.shutdown()
            overlay.hide()
            model?.close()
        } catch (e: Exception) { Log.e("Misha", "destroy", e) }
        super.onDestroy()
    }

    private fun notif(t: String): Notification =
        Notification.Builder(this, "misha").setContentTitle("Миша").setContentText(t)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()

    private fun note(t: String) { getSystemService(NotificationManager::class.java).notify(1, notif(t)) }

    // ---- Голосовая модель Vosk (скачивается один раз) ----
    private fun ensureModel(): Boolean {
        if (model != null) return true
        val dir = File(filesDir, "vosk-model-small-ru-0.22")
        if (!File(dir, "am").isDirectory) {
            note("Скачиваю голосовую модель (около 45 МБ)…")
            try {
                val z = File(cacheDir, "m.zip")
                val c = URL("https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip").openConnection() as HttpURLConnection
                c.connectTimeout = 20000
                c.readTimeout = 60000
                c.inputStream.use { i -> z.outputStream().use { o -> i.copyTo(o) } }
                ZipInputStream(z.inputStream()).use { zi ->
                    var e = zi.nextEntry
                    while (e != null) {
                        val f = File(filesDir, e.name)
                        if (!f.canonicalPath.startsWith(filesDir.canonicalPath)) throw IOException("bad zip")
                        if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { zi.copyTo(it) } }
                        e = zi.nextEntry
                    }
                }
                z.delete()
            } catch (e: Exception) {
                Log.e("Misha", "model", e); note("Не скачалась модель: ${e.message}"); return false
            }
        }
        return try { model = Model(dir.absolutePath); true } catch (e: Exception) { note("Ошибка модели: ${e.message}"); false }
    }

    // ---- Слушаем только при включённом и разблокированном экране ----
    @Synchronized
    private fun refresh() {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val ok = pm.isInteractive && !km.isKeyguardLocked
        if (ok && worker == null && model != null) {
            val f = AtomicBoolean(true)
            flag = f
            worker = Thread { loop(f) }.also { it.start() }
            note("Слушаю. Скажите: Миша")
        } else if (!ok && worker != null) {
            flag?.set(false); flag = null
            val w = worker
            worker = null
            speaker.stop()
            try { w?.join(400) } catch (e: InterruptedException) {}
            note("Экран заблокирован, не слушаю")
        }
    }

    private fun wakeNames(): List<String> {
        val l = prefs.s("names", Prefs.NAMES).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        return if (l.isEmpty()) Prefs.NAMES.split(",") else l
    }

    // ---- Главный цикл: Vosk на телефоне ждёт имя, в интернет ничего не уходит ----
    private fun loop(f: AtomicBoolean) {
        val m = model ?: return
        val names = wakeNames()
        val rec = Recognizer(m, 16000f, JSONArray(names + "[unk]").toString())
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8000) * 2)
        try {
            if (ar.state != AudioRecord.STATE_INITIALIZED) { note("Нет доступа к микрофону"); return }
            ar.startRecording()
            val buf = ByteArray(3200)
            val utt = ByteArrayOutputStream()
            while (f.get()) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) { Thread.sleep(50); continue }
                utt.write(buf, 0, n)
                if (utt.size() > 320000) { val b = utt.toByteArray(); utt.reset(); utt.write(b, b.size - 96000, 96000) }
                if (rec.acceptWaveForm(buf, n)) {
                    val t = JSONObject(rec.result).optString("text")
                    if (names.any { t.contains(it) }) {
                        val pcm = utt.toByteArray()
                        utt.reset()
                        ar.stop()
                        session(pcm, f, ar)
                        if (f.get()) { rec.reset(); ar.startRecording() }
                    } else utt.reset()
                }
            }
        } catch (e: Exception) {
            Log.e("Misha", "loop", e)
        } finally {
            try { ar.release() } catch (e: Exception) {}
            rec.close()
            synchronized(this) { if (flag === f) { flag = null; worker = null } }
        }
    }

    // ---- Запись одной фразы: ждём начала речи и тишину в конце ----
    private fun record(ar: AudioRecord, f: AtomicBoolean, waitMs: Int, maxMs: Int): ByteArray? {
        ar.startRecording()
        val buf = ByteArray(3200)
        val prev = ByteArray(3200)
        var hasPrev = false
        val out = ByteArrayOutputStream()
        var started = false
        var quiet = 0
        var t = 0
        var noise = 300.0
        try {
            while (f.get() && t < maxMs) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) break
                t += 100
                val lvl = rms(buf, n)
                val loud = lvl > maxOf(800.0, noise * 3)
                if (!started) {
                    noise = noise * 0.9 + lvl * 0.1
                    if (loud) { started = true; if (hasPrev) out.write(prev) } else { System.arraycopy(buf, 0, prev, 0, n); hasPrev = true }
                }
                if (started) {
                    out.write(buf, 0, n)
                    if (loud) quiet = 0 else quiet += 100
                    if (quiet >= 1200) break
                } else if (t >= waitMs) return null
            }
        } finally { try { ar.stop() } catch (e: Exception) {} }
        return if (started) out.toByteArray() else null
    }

    private fun rms(b: ByteArray, n: Int): Double {
        var s = 0.0
        var i = 0
        while (i + 1 < n) {
            val v = ((b[i].toInt() and 255) or (b[i + 1].toInt() shl 8)).toShort().toDouble()
            s += v * v
            i += 2
        }
        return Math.sqrt(s / maxOf(n / 2, 1))
    }

    private fun beep() {
        try {
            val g = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            g.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            Thread.sleep(220)
            g.release()
        } catch (e: Exception) {}
    }

    private fun say(t: String) { overlay.state("speaking"); speaker.say(t) }

    private fun stt(pcm: ByteArray): String {
        val t = Api.transcribe(prefs.s("groqKey"), pcm)
        val l = t.lowercase()
        val junk = listOf("субтитры", "продолжение следует", "спасибо за просмотр", "редактор")
        return if (l.length < 2 || junk.any { l.contains(it) }) "" else t
    }

    private fun stripWake(t: String, names: List<String>): String {
        val re = Regex("^[\\s,.!?:;-]*(" + names.joinToString("|") { Regex.escape(it) } + ")[\\s,.!?:;-]*")
        val cut = re.find(t.lowercase())?.value?.length ?: 0
        return t.substring(minOf(cut, t.length)).trim()
    }

    private fun stopPhrase(t: String) = Regex("(?U)\\b(пока|до свидания|отбой|хватит)\\b").containsMatchIn(t.lowercase())

    // ---- Сессия: проверка имени, поздравление, команды и разговор ----
    private fun session(first: ByteArray, f: AtomicBoolean, ar: AudioRecord) {
        val short = prefs.s("short").ifEmpty { "друг" }
        val male = prefs.s("gender", "m") == "m"
        val (skin, greet) = Holidays.today(Calendar.getInstance(), male, prefs.s("birth"))
        overlay.show(skin)
        overlay.state("thinking")
        try {
            if (prefs.s("orKey").isEmpty() || prefs.s("groqKey").isEmpty()) { say("Нужно ввести ключи в настройках."); return }
            val names = wakeNames()
            val heard = stt(first)
            if (names.none { heard.lowercase().contains(it) }) return   // ложное срабатывание
            var cmd = stripWake(heard, names)
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            if (greet != null && prefs.s("lastGreet") != today) {      // поздравляем один раз в день
                prefs.put("lastGreet", today)
                overlay.state("happy")
                speaker.say("$short, поздравляю тебя $greet! Здоровья тебе и тепла.")
            }
            history.clear()
            if (cmd.length < 3) {                                       // сказали только имя
                overlay.state("listening"); beep()
                val p = record(ar, f, 5000, 12000) ?: return
                overlay.state("thinking")
                cmd = stt(p)
            }
            while (f.get()) {
                if (cmd.isBlank()) break
                if (stopPhrase(cmd)) { say("Хорошо, зови, если что."); break }
                val (reply, act) = ask(cmd)
                say(reply)
                var launched = false
                when (act?.optString("type") ?: "") {
                    "open_app" -> { launched = Apps.open(this, act!!.optString("app")) != null; if (!launched) speaker.say("Не нашёл такое приложение.") }
                    "search" -> launched = Apps.search(this, act!!.optString("app"), act.optString("query"))
                }
                if (launched) { Thread.sleep(1500); break }
                overlay.state("listening")
                val p = record(ar, f, 6000, 15000) ?: break            // окно для продолжения разговора
                overlay.state("thinking")
                cmd = stt(p)
            }
        } catch (e: Exception) {
            Log.e("Misha", "session", e)
            val m = e.message ?: ""
            speaker.say(if (m.contains("HTTP 401") || m.contains("HTTP 403")) "Не подходят ключи. Проверь настройки." else "Нет связи. Попробуй ещё раз.")
        } finally {
            history.clear()
            overlay.hide()
        }
    }

    private fun ask(user: String): Pair<String, JSONObject?> {
        val gender = if (prefs.s("gender", "m") == "m") "мужчина" else "женщина"
        val apps = Apps.list(this).map { it.first }.sorted().take(80).joinToString(", ")
        val day = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("ru")).format(Date())
        val sys = """
            Ты — Миша, голосовой помощник на телефоне. С тобой говорит ${prefs.s("short")} (полное имя: ${prefs.s("full")}), пожилой человек (${gender}). Обращайся на «ты», по имени, с учётом его пола.
            Говори просто, тепло и коротко: 1–3 предложения, без списков, смайликов и markdown. Твой ответ будут озвучивать вслух. Сегодня: ${day}.
            Ты управляешь телефоном. ВСЕГДА отвечай ТОЛЬКО одним JSON-объектом, без другого текста:
            {"say":"что сказать вслух","action":null}
            или {"say":"...","action":{"type":"open_app","app":"название приложения"}}
            или {"say":"...","action":{"type":"search","app":"youtube или web","query":"что искать"}}
            Просят открыть приложение — open_app. Просят найти или включить видео, песню, фильм, рецепт, погоду, новости — search (app=youtube для видео и музыки, иначе web). Просто разговаривают — action null, отвечай по-человечески. Не выдумывай факты, если не знаешь, так и скажи.
            Установленные приложения: ${apps}
        """.trimIndent()
        val msgs = ArrayList<Pair<String, String>>()
        msgs.add("system" to sys)
        msgs.addAll(history.takeLast(8))
        msgs.add("user" to user)
        val raw = Api.chat(prefs.s("orKey"), prefs.s("model", Prefs.MODEL), msgs)
            .replace(Regex("(?s)<think>.*?</think>"), "").trim()
        var say = raw
        var act: JSONObject? = null
        val a = raw.indexOf('{')
        val b = raw.lastIndexOf('}')
        if (a >= 0 && b > a) {
            try {
                val j = JSONObject(raw.substring(a, b + 1))
                say = j.optString("say", "")
                act = j.optJSONObject("action")
            } catch (e: Exception) {}
        }
        history.add("user" to user)
        history.add("assistant" to raw)
        return say to act
    }
}
