package ru.misha.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// Голос Миши: системный синтез речи (если поставить RHVoice и выбрать его в настройках телефона, будет он)
class Speaker(ctx: Context) {
    private var tts: TextToSpeech? = null
    private val ready = CountDownLatch(1)
    @Volatile private var ok = false
    @Volatile private var done: CountDownLatch? = null

    init {
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                ok = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setSpeechRate(0.9f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { done?.countDown() }
                    override fun onError(id: String?) { done?.countDown() }
                    override fun onStop(id: String?, interrupted: Boolean) { done?.countDown() }
                })
            }
            ready.countDown()
        }
    }

    fun say(text: String) {
        ready.await(5, TimeUnit.SECONDS)
        if (!ok || text.isBlank()) return
        val l = CountDownLatch(1)
        done = l
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        l.await(60, TimeUnit.SECONDS)
    }

    fun stop() { tts?.stop(); done?.countDown() }
    fun shutdown() { tts?.shutdown() }
}
