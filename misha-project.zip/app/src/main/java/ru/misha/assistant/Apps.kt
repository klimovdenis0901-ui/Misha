package ru.misha.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri

object Apps {
    private val syn = mapOf(
        "ютуб" to "youtube", "ютюб" to "youtube", "ватсап" to "whatsapp", "вотсап" to "whatsapp", "вайбер" to "viber",
        "телеграм" to "telegram", "камера" to "camera", "галерея" to "gallery", "фото" to "photos", "карты" to "maps",
        "браузер" to "chrome", "хром" to "chrome", "почта" to "mail", "календарь" to "calendar", "часы" to "clock",
        "настройки" to "settings", "телефон" to "dialer", "контакты" to "contacts", "сообщения" to "messag",
        "одноклассники" to "odnoklassniki", "вконтакте" to "vk", "вк" to "vk", "музыка" to "music", "калькулятор" to "calc"
    )

    fun list(ctx: Context): List<Pair<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = ctx.packageManager
        return pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }
            .distinct()
    }

    fun open(ctx: Context, name: String): String? {
        val n = name.lowercase().trim()
        if (n.isEmpty()) return null
        val s = syn[n] ?: n
        val apps = list(ctx)
        val hit = apps.firstOrNull { it.first.lowercase() == n }
            ?: apps.firstOrNull { it.first.lowercase().contains(s) || it.second.lowercase().contains(s) }
            ?: apps.firstOrNull { it.first.length >= 3 && n.contains(it.first.lowercase()) }
            ?: return null
        val i = ctx.packageManager.getLaunchIntentForPackage(hit.second) ?: return null
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return hit.first
    }

    fun search(ctx: Context, app: String, q: String): Boolean {
        if (q.isBlank()) return false
        val a = app.lowercase()
        val i = if (a.contains("youtube") || a.contains("ютуб"))
            Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        else
            Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i); true
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
            } catch (e2: Exception) { false }
        }
    }
}
