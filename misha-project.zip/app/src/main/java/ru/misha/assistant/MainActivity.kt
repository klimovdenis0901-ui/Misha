package ru.misha.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var p: Prefs
    private val fields = LinkedHashMap<String, EditText>()
    private lateinit var male: RadioButton
    private lateinit var female: RadioButton
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(48))

        fun label(t: String) { val v = TextView(this); v.text = t; v.textSize = 16f; v.setPadding(0, dp(16), 0, dp(4)); col.addView(v) }
        fun field(key: String, title: String, def: String = "") {
            label(title)
            val e = EditText(this); e.setText(p.s(key, def)); e.textSize = 18f; e.setSingleLine()
            col.addView(e); fields[key] = e
        }
        fun button(t: String, a: () -> Unit) { val v = Button(this); v.text = t; v.textSize = 17f; v.setOnClickListener { a() }; col.addView(v) }

        val title = TextView(this); title.text = "Миша"; title.textSize = 30f; col.addView(title)
        status = TextView(this); status.textSize = 16f; col.addView(status)

        field("full", "Полное имя (например: Юрий)")
        field("short", "Как называть (например: Юра)")
        label("Пол (чтобы не поздравлять с чужими праздниками)")
        val rg = RadioGroup(this)
        male = RadioButton(this); male.text = "Мужчина"; male.id = 101
        female = RadioButton(this); female.text = "Женщина"; female.id = 102
        rg.addView(male); rg.addView(female); col.addView(rg)
        if (p.s("gender", "m") == "f") female.isChecked = true else male.isChecked = true
        field("birth", "Дата рождения (дд.мм.гггг)")
        field("names", "Как можно звать (через запятую)", Prefs.NAMES)
        field("orKey", "Ключ OpenRouter")
        field("groqKey", "Ключ Groq")
        field("model", "Модель OpenRouter", Prefs.MODEL)

        button("1. Разрешить микрофон и уведомления") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        button("2. Разрешить «поверх других окон»") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("3. Не засыпать в фоне") {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (e: Exception) {}
        }
        button("Проверить голос Миши") {
            save()
            val s = Speaker(applicationContext)
            val n = p.s("short", "друг").ifEmpty { "друг" }
            Thread { s.say("Привет, $n! Я Миша. Зови меня, если что."); s.shutdown() }.start()
        }
        button("Сохранить и включить Мишу") { save(); start() }
        button("Выключить") { stopService(Intent(this, ListenService::class.java)); refreshStatus() }

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    private fun save() {
        fields.forEach { (k, e) -> p.put(k, e.text.toString().trim()) }
        p.put("gender", if (female.isChecked) "f" else "m")
    }

    private fun refreshStatus() {
        val miss = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) miss.add("микрофон")
        if (!Settings.canDrawOverlays(this)) miss.add("«поверх окон»")
        if (p.s("orKey").isEmpty() || p.s("groqKey").isEmpty()) miss.add("ключи")
        status.text = if (miss.isEmpty()) "Всё готово. Нажми «Сохранить и включить»." else "Не хватает: " + miss.joinToString(", ")
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Сначала разреши микрофон (кнопка 1)"
            return
        }
        val i = Intent(this, ListenService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        status.text = "Миша включён. Скажи: Миша"
    }
}
