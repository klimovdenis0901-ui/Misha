package ru.misha.assistant

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("misha", Context.MODE_PRIVATE)
    fun s(k: String, d: String = ""): String = p.getString(k, d) ?: d
    fun put(k: String, v: String) { p.edit().putString(k, v).apply() }

    companion object {
        const val NAMES = "миша,михаил,мишаня,миш,мишка"
        const val MODEL = "nvidia/nemotron-3-nano-30b-a3b:free"
    }
}
