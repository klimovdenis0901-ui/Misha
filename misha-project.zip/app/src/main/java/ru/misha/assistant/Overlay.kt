package ru.misha.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient

// Аватар Миши поверх всех окон (анимация из assets/avatar.html)
class Overlay(private val ctx: Context) {
    private val h = Handler(Looper.getMainLooper())
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var web: WebView? = null
    private var loaded = false
    private var skin = "none"
    private var st = "appear"

    private fun push() {
        if (loaded) web?.evaluateJavascript("setSkin('$skin');setState('$st')", null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun show(newSkin: String) {
        h.post {
            skin = newSkin
            st = "appear"
            if (!Settings.canDrawOverlays(ctx)) return@post
            if (web != null) { push(); return@post }
            loaded = false
            val w = WebView(ctx)
            w.setBackgroundColor(Color.TRANSPARENT)
            w.settings.javaScriptEnabled = true
            w.webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, u: String?) { loaded = true; push() }
            }
            w.loadUrl("file:///android_asset/avatar.html")
            val size = (ctx.resources.displayMetrics.density * 170).toInt()
            val lp = WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.END
            lp.x = 24
            lp.y = 180
            wm.addView(w, lp)
            web = w
        }
    }

    fun state(s: String) { h.post { st = s; push() } }

    fun hide() {
        h.post {
            val w = web ?: return@post
            if (loaded) w.evaluateJavascript("setState('bye')", null)
            h.postDelayed({
                try { wm.removeView(w) } catch (e: Exception) {}
                w.destroy()
                if (web === w) { web = null; loaded = false }
            }, 600)
        }
    }
}
