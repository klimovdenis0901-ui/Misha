package ru.misha.assistant

import java.util.Calendar

object Holidays {
    // Православная Пасха (по григорианскому календарю), 1900-2099
    private fun easter(y: Int): Calendar {
        val a = y % 4
        val b = y % 7
        val c = y % 19
        val d = (19 * c + 15) % 30
        val e = (2 * a + 4 * b - d + 34) % 7
        val s = d + e + 114
        val cal = Calendar.getInstance()
        cal.clear()
        cal.set(y, s / 31 - 1, s % 31 + 1 + 13)
        return cal
    }

    // Возвращает (наряд, поздравление или null). male: чтобы мужчину не поздравить с 8 Марта, а женщину с 23 Февраля.
    fun today(now: Calendar, male: Boolean, birth: String): Pair<String, String?> {
        val m = now.get(Calendar.MONTH) + 1
        val d = now.get(Calendar.DAY_OF_MONTH)
        val bp = birth.split(".")
        if (bp.size >= 2 && bp[0].trim().toIntOrNull() == d && bp[1].trim().toIntOrNull() == m)
            return "bday" to "с днём рождения"
        val e = easter(now.get(Calendar.YEAR))
        if (e.get(Calendar.MONTH) + 1 == m && e.get(Calendar.DAY_OF_MONTH) == d)
            return "easter" to "с Пасхой! Христос воскресе"
        return when ("$m-$d") {
            "12-31" -> "ny" to "с наступающим Новым годом"
            "1-1" -> "ny" to "с Новым годом"
            "1-7" -> "ny" to "с Рождеством"
            "1-14" -> "ny" to "со Старым Новым годом"
            "2-23" -> if (male) "feb23" to "с Днём защитника Отечества" else "none" to null
            "3-8" -> if (!male) "mar8" to "с Восьмым марта" else "none" to null
            "5-9" -> "may9" to "с Днём Победы"
            "10-1" -> "elders" to "с Днём пожилых людей"
            "10-31" -> "halloween" to "с Хэллоуином"
            else -> "none" to null
        }
    }
}
