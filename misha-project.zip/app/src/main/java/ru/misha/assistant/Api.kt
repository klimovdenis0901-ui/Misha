package ru.misha.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

object Api {
    private fun wav(pcm: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        val d = DataOutputStream(out)
        fun le32(v: Int) { d.write(v and 255); d.write(v shr 8 and 255); d.write(v shr 16 and 255); d.write(v shr 24 and 255) }
        fun le16(v: Int) { d.write(v and 255); d.write(v shr 8 and 255) }
        d.writeBytes("RIFF"); le32(36 + pcm.size); d.writeBytes("WAVEfmt "); le32(16)
        le16(1); le16(1); le32(16000); le32(32000); le16(2); le16(16)
        d.writeBytes("data"); le32(pcm.size); d.write(pcm)
        return out.toByteArray()
    }

    private fun read(c: HttpURLConnection): String {
        val ok = c.responseCode in 200..299
        val s = if (ok) c.inputStream else c.errorStream
        val t = s?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (!ok) throw IOException("HTTP ${c.responseCode}: $t")
        return t
    }

    // Groq Whisper: звук -> текст
    fun transcribe(key: String, pcm: ByteArray): String {
        val b = "----misha" + UUID.randomUUID()
        val c = URL("https://api.groq.com/openai/v1/audio/transcriptions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
        val o = DataOutputStream(c.outputStream)
        fun field(n: String, v: String) { o.writeBytes("--$b\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n") }
        field("model", "whisper-large-v3-turbo")
        field("language", "ru")
        field("response_format", "json")
        field("temperature", "0")
        o.writeBytes("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
        o.write(wav(pcm))
        o.writeBytes("\r\n--$b--\r\n")
        o.flush()
        return JSONObject(read(c)).optString("text", "").trim()
    }

    // OpenRouter: диалог с нейросетью
    fun chat(key: String, model: String, msgs: List<Pair<String, String>>): String =
        try { chatRaw(key, model, msgs, true) } catch (e: IOException) { chatRaw(key, model, msgs, false) }

    private fun chatRaw(key: String, model: String, msgs: List<Pair<String, String>>, noReasoning: Boolean): String {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.5).put("max_tokens", 1000)
        if (noReasoning) body.put("reasoning", JSONObject().put("enabled", false))
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 45000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val j = JSONObject(read(c))
        return j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "")
    }
}
